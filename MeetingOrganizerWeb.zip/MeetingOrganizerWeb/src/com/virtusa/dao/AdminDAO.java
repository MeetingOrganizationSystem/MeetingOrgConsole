package com.virtusa.dao;

import java.util.List;

import com.virtusa.entities.Rooms;

public interface AdminDAO {
	public int addRoom(Rooms room);
	public int updateRoom(Rooms room);
	public List<Rooms> viewAllInfo();
	public int deleteRoom(int room_no);
	public boolean authenticate(String userName,String password);
}
