package com.virtusa.dao;

public class OrganizerDAOImpl implements OrganizerDAO {

}
