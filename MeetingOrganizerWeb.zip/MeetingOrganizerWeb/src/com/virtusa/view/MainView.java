package com.virtusa.view;

import java.util.Scanner;


import com.virtusa.service.AdminService;
import com.virtusa.service.MeetingOrganizerService;

public class MainView {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		AdminService adminService=new AdminService();
		MeetingOrganizerService meetingorganizerService=new MeetingOrganizerService();
		System.out.println();
		adminService.login();
		while(true)
		{
			System.out.println("Welcome Admin");
		System.out.println("1.Add Room\n 2.Update Room\n 3.Delete Room\n 4.View All Information\n 5.Exit");	
		int choice=scanner.nextInt();
		switch(choice){
		case 1: adminService.addRoom();
		    break;
		case 2: adminService.updateRoom();
		 	break;
		case 3: adminService.deleteRoom();
			break;
		case 4: adminService.viewAllInfo();
			break;
		case 5:meetingorganizerService.login();
			System.out.println("Welcome Meeting Organizer");
			adminService.viewAllInfo();
			 meetingorganizerService.org();
		default:
			System.out.println("choose number from given choice");
			}
		}
	}
}
